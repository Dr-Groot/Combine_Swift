//
//  ViewController.swift
//  CombineIntroThree
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import UIKit
import Combine

class ViewController: UIViewController {
    
    let viewModel = ViewModel()
    var observers: Set<AnyCancellable> = []

    override func viewDidLoad() {
        super.viewDidLoad()
        
        configDependency()
        viewModel.getDataSet()
    }
    
    private func configDependency() {
        viewModel.dotaHeroDataObserver
            .sink(receiveCompletion: {completetion in
                switch completetion {
//                  It is called at last when data is recieved.
                case .finished:
//                  called when successfully recieved data
                    print("FINISHED")
                case .failure(let error):
//                    called when recieving error from api calling.
                    print("ERROR: \(error)")
                }
            }, receiveValue: {data in
                print(data)
            }).store(in: &observers)
    }
}
