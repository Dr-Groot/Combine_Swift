//
//  DotaServices.swift
//  CombineIntroThree
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import Foundation
import Moya

enum DotaService {
    case heroStats
}

extension DotaService: TargetType {
    var baseURL: URL {
        guard let url = URL(string: "https://api.opendota.com") else { fatalError() }
        return url
    }

    var path: String {
        switch self {
        case .heroStats:
            return "/api/heroStats"
        }
    }

    var method: Moya.Method {
        switch self {
        case .heroStats:
            return .get
        }
    }

    var sampleData: Data {
        let json = ""
        return json.data(using: String.Encoding.utf8)!
    }

    var task: Moya.Task {
        switch self {
        case .heroStats:
            return .requestPlain
        }
    }

    var headers: [String : String]? {
        return nil
    }
}
