//
//  ViewModel.swift
//  CombineIntroThree
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import Foundation
import Moya
import Combine

class ViewModel {
    
    var observers: Set<AnyCancellable> = []
    let dotaServiceProvider = MoyaProvider<DotaService>()
    var dotaHeroDataObserver = PassthroughSubject<HERO, Error>()
    
    
    func getDataSet() {
//        Set default data
        dotaHeroDataObserver.send([.default])
        
//        Fetching data
       dotaServiceProvider.requestPublisher(.heroStats)
            .sink(receiveCompletion: { completion in
                switch completion {
                case .finished:
                    print("Fininshed data loading")
                case .failure(let error):
                    self.dotaHeroDataObserver.send(completion: .failure(error))
                }
            }, receiveValue: {response in
                let responseData = try! JSONDecoder().decode(HERO.self, from: response.data)
                self.dotaHeroDataObserver.send(responseData)
                self.dotaHeroDataObserver.send(completion: .finished)
            }).store(in: &observers)
    }
}
