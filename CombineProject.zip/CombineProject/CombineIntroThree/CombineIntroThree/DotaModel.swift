//
//  DotaModel.swift
//  CombineIntroThree
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import Foundation

struct HeroElement: Codable {
    let id: Int
    let name: String
    let localizedName: String
    let primaryAttr: String
    let attackType: String
    let roles: [String]
    let img: String
    let icon: String
    let baseHealth: Int
    let baseHealthRegen: Double
    let baseMana: Int
    let baseManaRegen: Double
    let baseArmor: Double
    let baseMr: Int
    let baseAttackMin: Int
    let baseAttackMax: Int
    let baseStr: Int
    let baseAgi, baseInt: Int
    let strGain: Double
    let agiGain: Double
    let intGain: Double
    let attackRange: Int
    let projectileSpeed: Int
    let attackRate: Double
    let moveSpeed: Int
    let turnRate: Double?
    let cmEnabled: Bool
    let legs: Int
    let heroID: Int
    let turboPicks: Int
    let turboWINS: Int
    let proBan: Int
    let proWin: Int?
    let proPick: Int?
    let the1_Pick: Int
    let the1_Win: Int
    let the2_Pick: Int
    let the2_Win: Int
    let the3_Pick: Int
    let the3_Win: Int
    let the4_Pick: Int
    let the4_Win: Int
    let the5_Pick: Int
    let the5_Win: Int
    let the6_Pick: Int
    let the6_Win: Int
    let the7_Pick: Int
    let the7_Win: Int
    let the8_Pick: Int
    let the8_Win: Int
    let nullPick: Int
    let nullWin: Int

    enum CodingKeys: String, CodingKey {
        case id
        case name
        case localizedName = "localized_name"
        case primaryAttr = "primary_attr"
        case attackType = "attack_type"
        case roles
        case img
        case icon
        case baseHealth = "base_health"
        case baseHealthRegen = "base_health_regen"
        case baseMana = "base_mana"
        case baseManaRegen = "base_mana_regen"
        case baseArmor = "base_armor"
        case baseMr = "base_mr"
        case baseAttackMin = "base_attack_min"
        case baseAttackMax = "base_attack_max"
        case baseStr = "base_str"
        case baseAgi = "base_agi"
        case baseInt = "base_int"
        case strGain = "str_gain"
        case agiGain = "agi_gain"
        case intGain = "int_gain"
        case attackRange = "attack_range"
        case projectileSpeed = "projectile_speed"
        case attackRate = "attack_rate"
        case moveSpeed = "move_speed"
        case turnRate = "turn_rate"
        case cmEnabled = "cm_enabled"
        case legs
        case heroID = "hero_id"
        case turboPicks = "turbo_picks"
        case turboWINS = "turbo_wins"
        case proBan = "pro_ban"
        case proWin = "pro_win"
        case proPick = "pro_pick"
        case the1_Pick = "1_pick"
        case the1_Win = "1_win"
        case the2_Pick = "2_pick"
        case the2_Win = "2_win"
        case the3_Pick = "3_pick"
        case the3_Win = "3_win"
        case the4_Pick = "4_pick"
        case the4_Win = "4_win"
        case the5_Pick = "5_pick"
        case the5_Win = "5_win"
        case the6_Pick = "6_pick"
        case the6_Win = "6_win"
        case the7_Pick = "7_pick"
        case the7_Win = "7_win"
        case the8_Pick = "8_pick"
        case the8_Win = "8_win"
        case nullPick = "null_pick"
        case nullWin = "null_win"
    }

    static let `default` = HeroElement(id: 0, name: "", localizedName: "", primaryAttr: "", attackType: "", roles: [], img: "", icon: "", baseHealth: 0, baseHealthRegen: 0, baseMana: 0, baseManaRegen: 0, baseArmor: 0, baseMr: 0, baseAttackMin: 0, baseAttackMax: 0, baseStr: 0, baseAgi: 0, baseInt: 0, strGain: 0, agiGain: 0, intGain: 0, attackRange: 0, projectileSpeed: 0, attackRate: 0, moveSpeed: 0, turnRate: 0, cmEnabled: false, legs: 0, heroID: 0, turboPicks: 0, turboWINS: 0, proBan: 0, proWin: 0, proPick: 0, the1_Pick: 0, the1_Win: 0, the2_Pick: 0, the2_Win: 0, the3_Pick: 0, the3_Win: 0, the4_Pick: 0, the4_Win: 0, the5_Pick: 0, the5_Win: 0, the6_Pick: 0, the6_Win: 0, the7_Pick: 0, the7_Win: 0, the8_Pick: 0, the8_Win: 0, nullPick: 0, nullWin: 0)
}
typealias HERO = [HeroElement]
