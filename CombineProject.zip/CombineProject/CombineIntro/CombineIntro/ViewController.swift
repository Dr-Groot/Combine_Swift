//
//  ViewController.swift
//  CombineIntro
//
//  Created by Aman Pratap Singh on 11/08/23.
//

import Combine
import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var mainTableView: UITableView!
    
    var alpha: [String]?
//    Single observable can be mark like this.
//    var mainTableViewObserver: AnyCancellable?
    var observers : [AnyCancellable] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        configDependency()
    }
    
    func configDependency() {
        mainTableView.dataSource = self
        mainTableView.delegate = self
        
         NetworkManager.shared.fetchData()
            .receive(on: DispatchQueue.main)
            .sink(receiveCompletion: { completion in
            switch completion {
            case.finished:
                print("Finished")
            case .failure(let error):
                print("Error: \(error)")
            }
        }, receiveValue: { value in
            self.alpha = value
            self.mainTableView.reloadData()
        }).store(in: &observers)

    }
    

}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alpha?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! DemoTableViewCell?
        cell?.demoLabel.text = alpha?[indexPath.row]
        
        cell?.sendMessage.sink { string in
            print(string)
        }.store(in: &observers)
        
        return cell!
    }
    
}

