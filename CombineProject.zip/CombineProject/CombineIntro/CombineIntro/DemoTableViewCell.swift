//
//  DemoTableViewCell.swift
//  CombineIntro
//
//  Created by Aman Pratap Singh on 11/08/23.
//

import UIKit
import Combine

class DemoTableViewCell: UITableViewCell {
    
    @IBOutlet var demoLabel: UILabel!
    @IBOutlet var demoButton: UIButton!
    
    
    let sendMessage = PassthroughSubject<String, Never>()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        demoButton.addTarget(self, action: #selector(didTapButton), for: .touchUpInside)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @objc func didTapButton() {
        sendMessage.send("Buttton Was pressed")
    }

}
