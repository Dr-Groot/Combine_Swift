//
//  NetworkManager.swift
//  CombineIntro
//
//  Created by Aman Pratap Singh on 11/08/23.
//

import Foundation
import Combine

class NetworkManager {
    static let shared = NetworkManager()
    var data: [String] = ["Alpha", "Beta", "Gama"]
    
    
    func fetchData() -> Future<[String], Error> {
        return Future { promixe in
            promixe(.success(self.data))
        }
    }
}
