//
//  CounterHelper.swift
//  CombineIntoSecond
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import Foundation
import Combine

class Counter {
    static var value = 0
    
    var counterPublisher = PassthroughSubject<Int, Never>()

    func increment() {
        Counter.value += 1
        counterPublisher.send(Counter.value)
    }
}
