//
//  ViewController.swift
//  CombineIntoSecond
//
//  Created by Aman Pratap Singh on 14/08/23.
//

import UIKit
import Combine

class ViewController: UIViewController {
    
    let counter = Counter()
    var observers: [AnyCancellable] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        setCounter()
    }
    
    func setCounter() {
        counter.counterPublisher
            .sink {value in
                print(value)
            }.store(in: &observers)
    }

    @IBAction func didTapIncrementButton(_ sender: UIButton) {
        counter.increment()
    }
    

}

