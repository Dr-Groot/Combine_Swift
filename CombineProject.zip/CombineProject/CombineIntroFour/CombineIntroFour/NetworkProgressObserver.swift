//
//  NetworkProgressObserver.swift
//  CombineIntroFour
//
//  Created by Aman Pratap Singh on 16/08/23.
//

import Foundation
import Combine

final class NetworkProgressObserver: {
   private var subscribers: Set<AnyCancellable> = .init()
   private var urlRequest: URLRequest
   private var timer: Timer?
   @Published private(set) var progress: Double
   init(urlRequest: URLRequest, progress: Double) {
      self.urlRequest = urlRequest
      self.progress = progress
   }
   func startMonitoring() {
      Timer.publish(every: 1.0, on: .main, in: .common)
      .autoconnect()
      .sink(receiveValue: { [weak self] _ in
      self?.checkNetworkEndTimerIfNeeded()
      })
      .store(in: &subscribers)
   }
   @objc func checkNetworkEndTimerIfNeeded() {
      NetworkClient.shared.session.progress(for: urlRequest) { [weak self] progress in
         if progress == 100 {
            self?.invalidateTimer()
         }
         DispatchQueue.main.async { //Go back to the main thread here since we will probalby be updating UI on the delgate
            self?.progress = progress
         }
      }
   }
   func invalidateTimer() {
      timer?.invalidate()
      timer = nil
   }
}
