//
//  ViewModel.swift
//  CombineIntroFour
//
//  Created by Aman Pratap Singh on 16/08/23.
//


import Foundation
import Combine

enum HTTPError: LocalizedError {
    case statusCode
}

class ViewModel {
    
    var observers: Set<AnyCancellable> = []
    var dotaHeroDataObserver = PassthroughSubject<HERO, Error>()
    let url = URL(string: "https://api.opendota.com/api/heroStats")!
    
    func getDataSet() {
        dotaHeroDataObserver.send([.default])
      
        URLSession.shared.dataTaskPublisher(for: url)
        .tryMap { output in
            guard let response = output.response as? HTTPURLResponse, response.statusCode == 200 else {
                throw HTTPError.statusCode
            }
            return output.data
        }
        .decode(type: HERO.self, decoder: JSONDecoder())
        .eraseToAnyPublisher()
        .sink(receiveCompletion: { completion in
            switch completion {
            case .finished:
                self.dotaHeroDataObserver.send(completion: .finished)
            case .failure(let error):
                self.dotaHeroDataObserver.send(completion: .failure(error))
            }
        }, receiveValue: { heros in
            self.dotaHeroDataObserver.send(heros)
        }).store(in: &observers)
        

    }
}
